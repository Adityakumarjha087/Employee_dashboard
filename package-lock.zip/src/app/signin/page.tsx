"use client";
import { useRouter } from 'next/navigation';
import { useState } from 'react';

const bgImage = 'https://images.unsplash.com/photo-1557683316-973673baf926?auto=format&fit=crop&w=2000&q=80';

export default function SignInPage() {
  const router = useRouter();
  const [form, setForm] = useState({ email: '', password: '' });
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setForm({ ...form, [e.target.name]: e.target.value });
    setError('');
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setTimeout(() => {
      setLoading(false);
      const user = localStorage.getItem('user');
      if (!user) {
        setError('No user found. Please register first.');
        return;
      }
      const parsed = JSON.parse(user);
      if (parsed.email === form.email && parsed.password === form.password) {
        localStorage.setItem('auth', 'true');
        router.push('/dashboard');
      } else {
        setError('Invalid email or password.');
      }
    }, 1000);
  };

  return (
    <div
      className="min-h-screen flex items-center justify-center relative"
      style={{
        backgroundImage: `url(${bgImage})`,
        backgroundSize: 'cover',
        backgroundPosition: 'center',
        backgroundAttachment: 'fixed',
      }}
    >
      <div className="absolute inset-0 bg-gradient-to-br from-black/80 via-black/70 to-black/80 backdrop-blur-[2px]" />
      <div className="relative z-10 bg-white/95 dark:bg-[#181818]/95 rounded-3xl shadow-2xl p-12 w-full max-w-xl mx-4 flex flex-col gap-8 border border-gray-200 dark:border-gray-800 animate-fade-in">
        <h2 className="text-3xl font-extrabold text-center mb-2 tracking-tight text-gray-900 dark:text-white">Sign In to Your Account</h2>
        <form className="flex flex-col gap-5 mt-2" onSubmit={handleSubmit} autoComplete="off">
          <div className="relative group">
            <input
              type="email"
              name="email"
              value={form.email}
              onChange={handleChange}
              className="peer px-5 py-3 rounded-lg border border-gray-300 focus:outline-none focus:ring-2 focus:ring-blue-500 text-lg bg-white/90 dark:bg-[#23272f]/90 w-full transition-all duration-200"
              required
              autoComplete="off"
            />
            <label className={`absolute left-5 top-3 text-gray-500 pointer-events-none transition-all duration-200 ${form.email ? '-translate-y-6 text-xs text-blue-600' : 'peer-focus:-translate-y-6 peer-focus:text-xs peer-focus:text-blue-600'}`}>Email</label>
          </div>
          <div className="relative group">
            <input
              type="password"
              name="password"
              value={form.password}
              onChange={handleChange}
              className="peer px-5 py-3 rounded-lg border border-gray-300 focus:outline-none focus:ring-2 focus:ring-blue-500 text-lg bg-white/90 dark:bg-[#23272f]/90 w-full transition-all duration-200"
              required
              autoComplete="off"
            />
            <label className={`absolute left-5 top-3 text-gray-500 pointer-events-none transition-all duration-200 ${form.password ? '-translate-y-6 text-xs text-blue-600' : 'peer-focus:-translate-y-6 peer-focus:text-xs peer-focus:text-blue-600'}`}>Password</label>
          </div>
          {error && <div className="text-red-600 text-center text-sm font-semibold animate-pulse">{error}</div>}
          <button
            type="submit"
            className="w-full py-3 rounded-lg bg-blue-600 hover:bg-blue-700 text-white font-bold text-lg transition-all duration-300 mt-2 shadow-md hover:shadow-lg disabled:opacity-60 disabled:cursor-not-allowed transform hover:scale-[1.02]"
            disabled={loading}
          >
            {loading ? 'Signing in...' : 'Sign In'}
          </button>
        </form>
        <div className="text-center text-base text-gray-500 mt-2">
          New here?{' '}
          <button className="text-blue-600 hover:text-blue-700 font-semibold transition-colors duration-200" type="button" onClick={() => router.push('/signup')}>
            Create an account
          </button>
        </div>
      </div>
    </div>
  );
} 