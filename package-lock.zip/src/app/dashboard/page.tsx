"use client";
import { useEffect } from "react";
import { useRouter } from "next/navigation";

const stats = [
  { label: "Total Employees", value: "1,285" },
  { label: "Active Projects", value: "47" },
  { label: "Pending Tasks", value: "124" },
  { label: "Total Departments", value: "8" },
];

export default function DashboardPage() {
  const router = useRouter();

  useEffect(() => {
    if (typeof window !== "undefined" && localStorage.getItem("auth") !== "true") {
      router.push("/signin");
    }
  }, [router]);

  return (
    <div style={{ display: "flex", minHeight: "100vh", background: "#181f2a" }}>
      {/* Sidebar */}
      <aside style={{
        width: 250, background: "#1a2332", color: "#fff", padding: 24, display: "flex", flexDirection: "column", justifyContent: "space-between"
      }}>
        <div>
          <div style={{ fontWeight: "bold", fontSize: 24, marginBottom: 4 }}>Zenwork</div>
          <div style={{ fontSize: 14, color: "#b0b8c1", marginBottom: 32 }}>znwrk@gmail.com</div>
          <nav>
            {["Dashboard", "Employee", "Hiring", "Payroll", "Performance", "Attendance", "Files", "Schedule"].map((item) => (
              <div key={item} style={{
                margin: "18px 0", padding: "8px 16px", borderRadius: 8, background: item === "Dashboard" ? "#222b3a" : "none", fontWeight: item === "Dashboard" ? "bold" : "normal"
              }}>{item}</div>
            ))}
          </nav>
        </div>
        <div>
          <div style={{ fontSize: 13, color: "#b0b8c1", marginBottom: 8 }}>Get Pro Access</div>
          <button style={{
            width: "100%", padding: "8px 0", background: "#2563eb", color: "#fff", border: "none", borderRadius: 8, fontWeight: 600, cursor: "pointer"
          }}>Try Pro</button>
        </div>
      </aside>

      {/* Main Content */}
      <div style={{ flex: 1, display: "flex", flexDirection: "column" }}>
        {/* Topbar */}
        <header style={{
          display: "flex", justifyContent: "flex-end", alignItems: "center", padding: 20, background: "#222b3a"
        }}>
          <button onClick={() => router.push("/profile")} style={{
            marginRight: 24, color: "#fff", background: "none", border: "none", fontSize: 16, cursor: "pointer"
          }}>Profile</button>
          <button onClick={() => {
            localStorage.removeItem("auth");
            router.push("/signin");
          }} style={{
            color: "#ff4d4f", background: "none", border: "none", fontSize: 16, cursor: "pointer"
          }}>Logout</button>
        </header>

        {/* Dashboard Content */}
        <main style={{ padding: 40 }}>
          <div style={{
            background: "#222b3a", borderRadius: 16, padding: 32, marginBottom: 32, color: "#fff"
          }}>
            <h2 style={{ fontSize: 28, fontWeight: 700, marginBottom: 8 }}>Welcome back, abc!</h2>
            <div style={{ color: "#b0b8c1", marginBottom: 24 }}>abc@gmail.com</div>
            <div style={{
              background: "#181f2a", borderRadius: 12, padding: 24, marginBottom: 24
            }}>
              <div style={{ fontWeight: 600, fontSize: 18, marginBottom: 12 }}>Employee Search</div>
              <div style={{ display: "flex", gap: 12 }}>
                <input placeholder="Search by employee name or ID..." style={{
                  flex: 1, padding: 12, borderRadius: 8, border: "1px solid #333", background: "#181f2a", color: "#fff"
                }} />
                <button style={{
                  background: "#2563eb", color: "#fff", border: "none", borderRadius: 8, padding: "0 24px", fontWeight: 600, cursor: "pointer"
                }}>Search</button>
              </div>
            </div>
            {/* Stats */}
            <div style={{ display: "flex", gap: 24, marginBottom: 24 }}>
              {stats.map(stat => (
                <div key={stat.label} style={{
                  background: "#181f2a", borderRadius: 12, padding: 24, flex: 1, textAlign: "center"
                }}>
                  <div style={{ color: "#b0b8c1", marginBottom: 8 }}>{stat.label}</div>
                  <div style={{ fontSize: 32, fontWeight: 700 }}>{stat.value}</div>
                </div>
              ))}
            </div>
            {/* Recent Activity */}
            <div style={{
              background: "#181f2a", borderRadius: 12, padding: 24
            }}>
              <div style={{ fontWeight: 600, fontSize: 18, marginBottom: 12 }}>Recent Activity</div>
              <ul style={{ color: "#b0b8c1", fontSize: 15 }}>
                <li style={{ marginBottom: 8 }}>New employee onboarding request <span style={{ color: "#fff" }}>2 hours ago</span></li>
                <li>Project milestone completed <span style={{ color: "#fff" }}>4 hours ago</span></li>
              </ul>
            </div>
          </div>
        </main>
      </div>
    </div>
  );
} 