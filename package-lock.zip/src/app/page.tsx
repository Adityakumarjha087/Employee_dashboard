"use client";
import Navbar from '../components/Navbar';
import { useState } from 'react';

export default function Home() {
  return (
    <div className="min-h-screen flex flex-col bg-gradient-to-br from-[#e0e7ef] via-[#f8fafc] to-[#c7d2fe] dark:from-[#181c24] dark:via-[#101010] dark:to-[#23272f]">
      <Navbar />
      <main className="flex-1 w-full">
        {/* HERO SECTION */}
        <section id="home" className="w-full min-h-[80vh] flex flex-col items-center justify-center relative overflow-hidden">
          <div className="absolute inset-0 z-0">
            <img src="/hero-bg.jpg" alt="Corporate background" className="w-full h-full object-cover object-center opacity-80" />
            <div className="absolute inset-0 bg-gradient-to-b from-[#1e293b]/80 to-white/80 dark:to-[#101010]/80" />
          </div>
          <div className="relative z-10 w-full max-w-3xl px-4 text-center space-y-8 animate-fade-in">
            <h1 className="text-5xl md:text-6xl font-extrabold mb-4 bg-clip-text text-transparent bg-gradient-to-r from-blue-700 to-purple-600 dark:from-blue-400 dark:to-purple-400 drop-shadow-lg">
              Welcome to <span className="text-blue-700 dark:text-blue-400">Zenwork</span> Employee Dashboard
            </h1>
            <p className="text-xl md:text-2xl text-gray-700 dark:text-gray-300 max-w-2xl mx-auto leading-relaxed">
              A modern platform to manage employees, projects, and performance efficiently.
            </p>
            <div className="flex gap-4 justify-center mt-8">
              <button className="px-8 py-3 bg-blue-700 text-white rounded-full hover:bg-blue-800 transform hover:scale-105 transition-all duration-300 shadow-lg hover:shadow-xl font-semibold text-lg">
                Get Started
              </button>
              <button className="px-8 py-3 border-2 border-blue-700 text-blue-700 dark:text-blue-400 rounded-full hover:bg-blue-50 dark:hover:bg-blue-900/20 transform hover:scale-105 transition-all duration-300 font-semibold text-lg">
                Learn More
              </button>
            </div>
          </div>
        </section>

        {/* ABOUT US SECTION */}
        <section id="about" className="w-full py-24 flex flex-col items-center justify-center bg-white/70 dark:bg-[#181818]/70 backdrop-blur-sm">
          <div className="max-w-4xl w-full px-4">
            <div className="bg-white dark:bg-[#181818] rounded-2xl shadow-xl p-12">
              <h2 className="text-3xl md:text-4xl font-bold mb-6 text-center bg-clip-text text-transparent bg-gradient-to-r from-blue-700 to-purple-600 dark:from-blue-400 dark:to-purple-400">
                About Us
              </h2>
              <p className="text-lg text-gray-700 dark:text-gray-300 text-center leading-relaxed">
                We are a leading provider of corporate solutions, helping organizations streamline their HR and project management processes with cutting-edge technology.
              </p>
            </div>
          </div>
        </section>

        {/* BENEFITS SECTION */}
        <section id="benefits" className="w-full py-24 flex flex-col items-center justify-center">
          <div className="max-w-5xl w-full px-4">
            <div className="bg-white dark:bg-[#181818] rounded-2xl shadow-xl p-12">
              <h2 className="text-3xl md:text-4xl font-bold mb-8 text-center bg-clip-text text-transparent bg-gradient-to-r from-blue-700 to-purple-600 dark:from-blue-400 dark:to-purple-400">
                Benefits
              </h2>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                {[
                  { title: "Centralized Management", icon: "📊", desc: "All your HR and project data in one secure place." },
                  { title: "Real-time Tracking", icon: "⚡", desc: "Monitor employee and project status instantly." },
                  { title: "Performance Analytics", icon: "📈", desc: "Get actionable insights for better decisions." },
                  { title: "Secure Infrastructure", icon: "🔒", desc: "Enterprise-grade security for your data." }
                ].map((benefit, index) => (
                  <div key={index} className="flex items-start space-x-4 p-6 rounded-xl hover:bg-blue-50 dark:hover:bg-blue-900/20 transition-colors duration-300 shadow-sm">
                    <span className="text-4xl mt-1">{benefit.icon}</span>
                    <div>
                      <div className="text-lg font-semibold text-gray-800 dark:text-gray-200 mb-1">{benefit.title}</div>
                      <div className="text-gray-600 dark:text-gray-400 text-base">{benefit.desc}</div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </section>

        {/* COMPANY SECTION */}
        <section id="company" className="w-full py-24 flex flex-col items-center justify-center bg-white/70 dark:bg-[#181818]/70 backdrop-blur-sm">
          <div className="max-w-4xl w-full px-4">
            <div className="bg-white dark:bg-[#181818] rounded-2xl shadow-xl p-12">
              <h2 className="text-3xl md:text-4xl font-bold mb-6 text-center bg-clip-text text-transparent bg-gradient-to-r from-blue-700 to-purple-600 dark:from-blue-400 dark:to-purple-400">
                About Company
              </h2>
              <p className="text-lg text-gray-700 dark:text-gray-300 text-center leading-relaxed">
                Our company is committed to delivering innovative solutions that empower businesses to achieve more. With a focus on user experience and security, we ensure your data is always protected.
              </p>
            </div>
          </div>
        </section>
      </main>

      <footer className="w-full bg-white/95 dark:bg-[#101010]/95 border-t border-gray-100 dark:border-gray-800 py-8 backdrop-blur-sm">
        <div className="max-w-7xl mx-auto px-4 flex flex-col sm:flex-row items-center justify-between text-gray-500 text-sm">
          <span className="hover:text-blue-700 dark:hover:text-blue-400 transition-colors duration-300">
            &copy; {new Date().getFullYear()} Zenwork Corp. All rights reserved.
          </span>
          <span className="hover:text-blue-700 dark:hover:text-blue-400 transition-colors duration-300">
            Made with Next.js & Tailwind CSS
          </span>
        </div>
      </footer>
    </div>
  );
}
